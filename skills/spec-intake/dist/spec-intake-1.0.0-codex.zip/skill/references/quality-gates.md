# Quality Gates

Use this reference before claiming any spec package is ready.

## Contract Gates

Block ready output when:

- required IDs are missing or dangling
- `harness_workflow` is missing, not the required three-stage workflow, or lacks a Human PRD review gate
- `harness_workflow.execution_mode` is missing, invalid, or uses `reference_replay` while claiming completed Stage 3/live workflow readiness
- Human PRD approval lacks explicit `human_prd_review_approval` intent, Stage 3 authorization, or an artifact sha256 binding to the rendered `human-prd.md`
- `requirement_table` is missing or does not cover current-phase requirements
- `interaction_decision=proceed_without_questions` but Stage 1 lacks PRD-ready support for product context, target users, MVP boundary, acceptance/verification, implementation approach, source evidence, or agent execution refs
- execution-like Stage 1 input proceeds without source-backed implementation topology: control flow, modules, technical decisions, external component boundary, state handling, evidence outputs, subjective judgment boundary, or mechanical delivery checks when those are material
- a clarification `Q-*` is open-text instead of boolean, single-choice, or multi-choice
- `object_index` diverges from `objects`
- `SRC` payload lacks a valid `source_type` or auditable content/target for user sources
- `RB` unsupported claims are non-empty
- `traceability_summary` diverges from `render_blocks` or `traceability`
- `quality_gates` diverges from `gate_report.gate_id`
- top-level contract views diverge from `objects` and `object_index`
- `GATE-*` payload diverges from its `gate_report` row
- `CORE.status=blocked`, current `REQ.status=blocked`, or `STOP.status=triggered` affects readiness
- `GATE.status=blocked` affects the target
- `Q` or `ASM` blocks the target and has missing or open status
- `gate_report.status=warning` lacks message or required fix
- Human PRD and Agent PRD disagree on shared facts
- Human PRD or Agent PRD contains facts absent from the requirement table and canonical objects
- Human PRD is not a professional, formal Simplified Chinese review brief with revision record, product goal, construction scope, implementation approach, acceptance criteria and methods, roadmap, risks/open decisions, and references
- Human PRD lacks information density: goal, what to build, how to build it, how to verify it, and roadmap are empty, generic, or unsupported by canonical refs
- Human PRD implementation approach hides material execution topology that exists in the contract, such as external component methods, monitoring loop, judgment owner, evidence output, or mechanical checks
- Human PRD includes workflow process markers such as `Source contract:`, `Render status:`, or `render_status`
- Human PRD does not put revision record first or references last
- Human PRD substantive sections lack canonical source refs
- Human PRD substantive sections are heading-only, citation-only, or too thin to support human review
- Human PRD repeats Agent PRD execution-contract sections instead of summarizing them for human review
- Agent PRD is not a complete English PRD for another agent
- Agent PRD lacks a real product PRD body with metadata, summary, problem/background, users/personas, goals/outcomes, success metrics, scope/non-goals, user stories/use cases, functional requirements, non-functional guardrails, user flow/UX notes, acceptance criteria, release plan/roadmap, risks/assumptions/dependencies, open questions, and traceability
- Agent PRD lacks a traceable agent execution appendix with source, mission, requirement trace, input, execution, tool/integration, permission/safety, data/state, verification, output, stop, done, and forbidden-assumption sections
- Agent PRD lacks execution objects, verification, stop conditions, or done criteria
- execution-ready Agent PRD text is only an execution contract, contract-ref index, or instruction sheet rather than a complete PRD
- execution-ready Agent PRD has required headings but thin section bodies or misses current-phase `REQ`, `AC`, `VER`, `IN`, `EXE`, `OUT`, `STOP`, or `DONE` refs
- execution-ready Agent PRD omits non-empty implementation-model refs such as `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, or `DCT`, causing the implementation approach or integration boundary to disappear
- Stage 2 package cannot be validated independently with `--stage stage2`
- Stage 2 package contains downstream HLD or legacy task-plan artifacts
- Stage 2 package does not set `human_prd_review.status` to `pending` or `approved` after PRD rendering
- Stage 2 `approved` review state is not backed by a Human PRD approval source bound to the current `human-prd.md`
- Stage 2 `contract_summary.stage_ready` or `stage_blocked` does not match the review-gated stage state
- rendered requirements cannot be traced to source `REQ-*`
- decision traceability type, ref, and status do not agree
- resolved decisions lack resolution refs or `TRACE.relation` is outside the allowed relation vocabulary

## Stage 1 Question Quality Gate

When `interaction_decision=ask_user`, the clarification set must target the highest-risk blockers in the idea, not merely ask any valid closed-form questions.

Block or revise Stage 1 semantic readiness when:

- executor, agent, adapter, CLI, or automation ideas omit a closed-form question about the input contract while input shape is unclear
- an external component is central to the idea but no question confirms whether integration is via public CLI/API or internal implementation
- completion authority or output deliverable is unclear and no question combines or covers completion/output contract
- permission, credential, filesystem, network, external-write, or destructive-action boundaries are material and no closed-form question covers them
- questions introduce a new actor or component as the preferred path without also offering a neutral "keep blocked" or public-boundary option
- the first round uses all available questions on secondary details while a core execution boundary remains unresolved

For executor-like workflows with only three questions available, a strong first round usually covers: input contract, external component boundary, and combined completion/output contract.

## HLD Gates

Block ready HLD when:

- source Agent PRD status in the HLD does not match the canonical contract
- Human PRD approval is missing or not backed by `SRC.source_type=user_confirmation`
- Human PRD approval is generic, replay-only, not scoped to Human PRD review, or bound to a stale `human-prd.md` digest
- `high-level-design.json` is missing
- `source_artifacts` refs, file names, version, status, or phase type diverge from the contract
- HLD refs are missing or not from source contract
- required HLD narrative fields are empty
- structured HLD implementation sections are missing, empty, or lack contract refs
- current requirement, acceptance, verification, input, execution, output, stop, done, or non-empty implementation-model refs are not covered by the HLD
- control flow lacks ordered steps, actors/components, inputs, outputs, interactions, and failure/branch behavior
- data flow lacks source, transformation, target, and data refs
- data objects lack field-level design or lifecycle
- data object fields are not structured objects with `name`, boolean `required`, and `meaning`
- interface contracts lack provider, consumer, invocation, inputs, outputs, or error semantics
- technical decisions lack rationale or implementation notes
- real acceptance plan lacks concrete confirmed real environment, concrete confirmed real data, execution steps, expected results, evidence capture, acceptance owner, `mock_policy=forbidden`, or `SRC-*` evidence refs for environment/data/owner
- ready HLD design gates do not include all required `gate_key` values: `source_readiness`, `control_flow_readiness`, `data_flow_and_object_readiness`, `interface_state_readiness`, `technical_implementation_readiness`, `real_acceptance_readiness`, `hld_document_readiness`, and `task_boundary_readiness`
- a required ready HLD design gate is missing, duplicated, not `pass`, lacks evidence refs, or lacks evidence summary
- ready HLD uses a generic single pass design gate instead of separately reviewing source readiness, control flow, data/data objects, interface/state, technical implementation, real acceptance, HLD document readiness, and task boundary
- ready HLD contains mock, stub, fake, simulated, or synthetic acceptance substitutes
- ready HLD defers acceptance resources with wording such as "selected by downstream owner", "supplied later", "to be provided", `TBD`, or placeholders
- stop/risk/scope controls disappear
- future phase work enters current design without contract support
- HLD adds new facts
- design gate evidence uses `CHECK-*`, non-ID values, or missing refs
- `execution-task-plan.json`, task graphs, dependency edges, parallel groups, or implementation task cards appear in the package

## Subjective Review Rubric

Score each dimension `pass`, `revise`, or `fail`:

| Dimension | Pass condition |
| --- | --- |
| Product clarity | User, problem, value, MVP, non-goals, roadmap, and acceptance method are understandable and source-backed before PRD rendering. |
| Honesty | Unknowns are explicit and do not become facts. |
| Human usefulness | Human PRD lets a human reviewer quickly understand the goal, scope, approach, acceptance standards and methods, roadmap, risks, and evidence without workflow-process clutter. |
| Agent executability | Agent PRD is a complete English PRD that tells an agent what product to build, why it matters, who it serves, how success is measured, what is in/out of scope, what requirements and guardrails apply, what sources are authoritative, what tools and permissions are allowed, what to output, how to verify, and when to stop. |
| Execution topology | For execution-like ideas, the contract and PRDs clearly identify external components, public interface/method boundary, execution loop, state handling, subjective judgment owner, mechanical delivery checks, and evidence outputs. |
| HLD usefulness | The HLD gives an implementation-ready design with concrete control flow, data flow, data objects, interface contracts, state model, technical decisions, environment requirements, no-mock real acceptance plan, and risk controls without implementation task decomposition. |
| Traceability | Important claims link to contract refs and source refs. |
| Harness routing | Stage 3 is entered only after Human PRD approval, and revise feedback routes back through the requirement table. |
| Clarification quality | Stage 1 questions are closed-form and target the highest-risk missing boundaries for the idea type. |

Any `fail` blocks ready. Any `revise` requires either patching or explicitly downgrading output status.

## Validation Script

For Stage 1 packages, run:

```bash
python <path-to-spec-intake-skill>/scripts/validate_spec_intake_package.py <output-dir> --stage stage1
```

For Stage 2 PRD packages, run:

```bash
python <path-to-spec-intake-skill>/scripts/validate_spec_intake_package.py <output-dir> --stage stage2
```

For final packages, run:

```bash
python <path-to-spec-intake-skill>/scripts/validate_spec_intake_package.py <output-dir>
```

In this repository's development layout, run `python skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage1` for Stage 1 packages, `python skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage2` for Stage 2 PRD packages, or `python skill/scripts/validate_spec_intake_package.py <output-dir>` for final packages, from `skills/spec-intake`.

For repository development, also run:

```bash
python tests/validator_regression.py
```

The regression suite must include both blocked and ready fixtures, plus false-positive probes for HLD source readiness, forbidden legacy HLD output, HLD required fields, status, render-block refs, payload schema, object-index drift, summary drift, derived traceability, gate/report drift, readiness blockers, source payload auditability, design evidence type, phase source type, ID namespace failures, missing harness workflow state, missing requirement table, PRD-ready Stage 1 support gaps, Stage 2 standalone validation, Stage 2 downstream artifact leakage, thin Agent PRD sections, thin Human PRD sections, Stage 2 stage-summary drift, open-ended clarification questions, missing Human PRD approval, missing HLD, and generic HLD design-gate-only shortcuts.

Use the bundled Python executable if `python` is unavailable. Report the exact verdict. Do not claim validation passed if the script was skipped.
