# Contract Envelope Schema Notes

The executable validator is `skill/scripts/validate_spec_intake_package.py`. This document records the harness-specific schema additions.

## Required Harness Fields

`contract-envelope.json` must include:

- `harness_workflow`
- `interaction_decision`
- `requirement_table`

## `harness_workflow`

Required fields:

- `workflow_type`: `review_gated_self_improving_generation`
- `execution_mode`: `live_interactive` or `reference_replay`
- `execution_mode_reason`: non-empty explanation of why this run is live or replay
- `current_stage`: one of `stage_1_requirements_table`, `stage_2_prd_review`, `stage_3_hld`, `complete`, `blocked`
- `stage_order`: the three canonical stages in order
- `approval_gates.human_prd_review.status`: `not_started`, `pending`, `approved`, `revise`, or `failed`
- `approval_gates.human_prd_review.approved_by_ref`: required only when approved, and must reference a `SRC-*` user confirmation
- `revision_policy.max_review_rounds`
- `revision_policy.on_revise`: `update_requirement_table_then_rerender_prds`

`reference_replay` is for non-interactive regression/reference validation only. It cannot be used to claim a completed live Stage 3 workflow.

When `approval_gates.human_prd_review.status=approved`, the approval source payload must include:

- `confirmation_kind`: `human_prd_review_approval`
- `confirmation_intent`: `approve_human_prd_and_enter_stage_3`
- `confirmed_stage`: `stage_2_prd_review`
- `approved_artifacts`: a list containing an entry with `path=human-prd.md` and a `sha256` digest that matches the rendered artifact

## `interaction_decision`

Stage 1 must write an interaction decision before PRD rendering.

Required fields:

- `stage`: `stage_1_requirements_table`
- `decision`: `ask_user`, `proceed_without_questions`, or `blocked_draft`
- `can_ask_user`: boolean
- `reason`: non-empty explanation grounded in source refs
- `question_refs`: list of `Q-*` refs, non-empty when `decision=ask_user`
- `blocking_refs`: list of blocking `Q-*`, `ASM-*`, `STOP-*`, or `GATE-*` refs
- `source_refs`: non-empty list of `SRC-*` refs

`decision=proceed_without_questions` is forbidden when unresolved blocking questions, assumptions, stop conditions, or gates remain.

For executor, agent, adapter, CLI, automation, scheduler, or tool-orchestration ideas, `decision=proceed_without_questions` also requires execution topology support in `implementation_model`: non-empty control flow, modules, and technical decisions. These objects should be source-backed and should describe external component boundaries, runtime state handling, judgment boundaries, evidence outputs, and mechanical checks when material.

## `requirement_table`

Each row requires:

- `row_id`: `RT-###`
- `requirement_ref`: `REQ-*`
- `origin`: `explicit_fact`, `confirmed_fact`, `bounded_inference`, `assumption`, or `open_question`
- `source_refs`
- `problem`
- `user_value`
- `mvp_scope`
- `acceptance_summary`
- `target_artifact_refs`

Every current-phase `REQ-*` must have a requirement table row.

`origin` must match evidence:

- `explicit_fact` and `confirmed_fact` require at least one `SRC-*` in `source_refs`
- `assumption` requires at least one `ASM-*`
- `open_question` requires at least one `Q-*`
- `bounded_inference` requires at least one `SRC-*` and a `TRACE-*` with `relation=inferred_from` to the row's `requirement_ref`

## Question Objects

Every `Q-*` payload must include:

- `question_type`: `boolean`, `single_choice`, or `multi_choice`
- `options`: at least two non-empty strings, exactly two for `boolean`

## High-Level Design

Ready Stage 3 must include `high-level-design.json`, `high-level-design.md`, and `hld-semantic-review.json`. `high-level-design.json` is the structured HLD source. `high-level-design.md` is the formal readable HLD document. `hld-semantic-review.json` is the independent semantic review artifact. A JSON-only HLD is incomplete.

Ready `high-level-design.json` must include `design_status=ready`, `source_artifacts.agent_prd_ref=agent-prd.md`, non-empty `contract_refs`, all required HLD narrative fields, structured implementation sections (`control_flow_design`, `data_flow_design`, `data_objects`, `interface_contracts`, `state_model`, `technical_decisions`, `implementation_design`, `environment_requirements`), `real_acceptance_plan`, and `design_gate_report`.

Ready HLD must define concrete confirmed real-environment and real-data acceptance with acceptance command, preconditions, execution steps, expected results, expected artifact paths, mechanical checks, failure criteria, evidence capture, acceptance owner, `mock_policy=forbidden`, and `SRC-*` evidence refs for environment, real data, and acceptance owner. Mock, stub, fake, simulated, synthetic, deferred, placeholder, `TBD`, or "to be provided later" acceptance inputs are forbidden. Missing environment, real data, executable command, expected artifacts, failure criteria, interface, permission, deployment, or acceptance ownership information must route to Stage 3 user interaction or a blocked HLD with required fixes. Data object fields must be structured objects with `name`, boolean `required`, and `meaning`. Interface contracts must include source refs and must not use loose fallback language such as "or equivalent", "when needed", or "as needed". Ready HLD `design_gate_report` must include separate passing gates with fixed `gate_key` values for source readiness, control flow, data/data objects, interface/state, technical implementation, real acceptance, and task boundary.

Ready `high-level-design.md` must identify its source artifacts, cite canonical refs, include required sections (`Revision History`, `Scope And Goals`, `Architecture Overview`, `Control Flow`, `Data Flow`, `Data Objects`, `Interface Contracts`, `State Model`, `Technical Decisions`, `Implementation Design`, `Real Acceptance Plan`, `Risks And Guardrails`, `References`), contain diagrams and tables, cover current requirement, acceptance, execution, implementation, verification, output, stop, and done refs, render interface `source_refs`, render the exact acceptance command, render expected artifact paths, and visibly include source-backed interface precision plus executable acceptance design.

Ready `hld-semantic-review.json` must have `review_status=pass`, valid source artifact refs, fixed semantic dimensions (`source_traceability`, `control_flow_completeness`, `data_flow_and_objects`, `interface_precision`, `technical_implementation`, `executable_acceptance`, `markdown_parity`, `no_untraced_invention`, `task_boundary`), non-empty findings, non-empty contract refs, required source refs for source/interface/acceptance/Markdown parity dimensions, and empty required fixes for passing dimensions.

`execution-task-plan.json`, task graphs, dependency edges, parallel groups, and implementation task cards are forbidden outputs.
