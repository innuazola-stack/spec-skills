#!/usr/bin/env python3
"""Regression probes for the spec-intake package validator.

The workflow now ends at HLD. These probes focus on contract integrity, PRD
readiness, Stage 1 interaction decisions, requirement-table provenance, and the
new HLD-only Stage 3 boundary.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


ROOT = Path(__file__).resolve().parents[1]
BASE_BLOCKED = ROOT / "tests" / "fixtures" / "blocked-agent-prd-draft"
BASE_READY = ROOT / "tests" / "fixtures" / "ready-agent-prd-hld"
TMP = ROOT / ".tmp-validator-regression"
VALIDATOR = ROOT / "skill" / "scripts" / "validate_spec_intake_package.py"
STAGE1_LIVE = ROOT / "tests" / "live-runs" / "2026-05-27" / "executor-stage1"
STAGE2_LIVE = ROOT / "tests" / "live-runs" / "2026-05-27" / "executor-minimal-stage2"


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def make_case(name: str, mutate: Callable[[Path], None], base: Path = BASE_BLOCKED) -> Path:
    case_dir = TMP / name
    shutil.rmtree(case_dir, ignore_errors=True)
    shutil.copytree(base, case_dir)
    mutate(case_dir)
    return case_dir


def run_validator(case_dir: Path, *, stage: str | None = None) -> tuple[int, dict]:
    command = [sys.executable, str(VALIDATOR), str(case_dir)]
    if stage:
        command.extend(["--stage", stage])
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    result = subprocess.run(
        command,
        text=True,
        encoding="utf-8",
        capture_output=True,
        check=False,
        env=env,
    )
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        payload = {"ok": False, "errors": [result.stdout, result.stderr]}
    return result.returncode, payload


def noncanonical_object_namespace(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["FOO-001"] = {"type": "FOO", "payload": {"id": "FOO-001"}}
    write_json(path, contract)


def requested_agent_prd_without_render_block(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["render_blocks"] = ["RB-001"]
    contract["objects"].pop("RB-002", None)
    write_json(path, contract)


def ready_hld_from_draft_agent_prd(case_dir: Path) -> None:
    contract_path = case_dir / "contract-envelope.json"
    contract = read_json(contract_path)
    contract["render_status"]["agent_prd"] = "draft"
    write_json(contract_path, contract)

    hld_path = case_dir / "high-level-design.json"
    hld = read_json(hld_path)
    hld["source_artifacts"]["agent_prd_status"] = "draft"
    write_json(hld_path, hld)


def invalid_object_statuses(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["REQ-001"]["payload"]["status"] = "banana"
    contract["objects"]["GATE-001"]["payload"]["status"] = "banana"
    contract["gate_report"][0]["status"] = "banana"
    write_json(path, contract)


def render_block_wrong_source_ref_type(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["RB-001"]["payload"]["source_refs"] = ["REQ-001"]
    write_json(path, contract)


def contract_summary_drift(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["contract_summary"]["ready_targets"] = []
    contract["contract_summary"]["blocked_targets"] = ["agent_prd"]
    write_json(path, contract)


def traceability_summary_decision_wrong_type(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["traceability_summary"]["decision_traceability"] = [
        {
            "decision_type": "open_question",
            "decision_ref": "REQ-001",
            "status": "open",
            "affected_refs": ["REQ-001"],
        }
    ]
    write_json(path, contract)


def object_index_drift(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["object_index"]["REQ"] = []
    write_json(path, contract)


def core_blocked_ready(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["CORE-001"]["payload"]["status"] = "blocked"
    write_json(path, contract)


def stop_triggered_ready(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["STOP-001"]["payload"]["status"] = "triggered"
    write_json(path, contract)


def blocking_q_missing_status(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["Q-001"] = {
        "type": "Q",
        "payload": {
            "id": "Q-001",
            "question": "Which execution authority is confirmed?",
            "blocks_agent_prd": True,
        },
    }
    contract["open_questions"] = ["Q-001"]
    contract["object_index"]["Q"] = ["Q-001"]
    write_json(path, contract)


def user_confirmation_decision_ref(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["SRC-003"] = {
        "type": "SRC",
        "payload": {
            "id": "SRC-003",
            "source_type": "user_confirmation",
            "content": "User confirmed the Phase 1 execution boundary.",
        },
    }
    if "SRC-003" not in contract["sources"]:
        contract["sources"].append("SRC-003")
    if "SRC-003" not in contract["object_index"]["SRC"]:
        contract["object_index"]["SRC"].append("SRC-003")
    contract["traceability_summary"]["decision_traceability"] = [
        {
            "decision_type": "user_confirmation",
            "decision_ref": "SRC-003",
            "status": "confirmed",
            "affected_refs": ["PHASE-001", "REQ-001"],
        }
    ]
    write_json(path, contract)


def agent_prd_missing_required_sections(case_dir: Path) -> None:
    path = case_dir / "agent-prd.md"
    path.write_text(
        "# Agent PRD\n\n"
        "Source contract: contract-envelope.json\n\n"
        "render_status.agent_prd=execution_ready\n\n"
        "REQ-001 AC-001 VER-001 IN-001 EXE-001 OUT-001 STOP-001 DONE-001\n",
        encoding="utf-8",
    )


def agent_prd_execution_contract_only(case_dir: Path) -> None:
    path = case_dir / "agent-prd.md"
    path.write_text(
        "# Agent PRD\n\n"
        "Source contract: contract-envelope.json\n\n"
        "render_status.agent_prd=execution_ready\n\n"
        "## Source of Truth\n\nUse contract-envelope.json.\n\n"
        "## Reader and Mission\n\nReader: downstream agent. Mission: execute the contract.\n\n"
        "## Requirement Trace\n\nREQ-001 AC-001 VER-001.\n\n"
        "## Input Contract\n\nIN-001.\n\n"
        "## Scope Contract\n\nSCOPE-001.\n\n"
        "## Execution Contract\n\nEXE-001.\n\n"
        "## Tool and Integration Boundaries\n\nUse approved tools only.\n\n"
        "## Permissions and Safety\n\nFollow permissions.\n\n"
        "## Data and State Contract\n\nNo extra state.\n\n"
        "## Verification Contract\n\nVER-001.\n\n"
        "## Output Contract\n\nOUT-001.\n\n"
        "## Stop Conditions\n\nSTOP-001.\n\n"
        "## Done Criteria\n\nDONE-001.\n\n"
        "## Non-Goals\n\nNo extra scope.\n\n"
        "## Open Questions and Assumptions\n\nNone blocking.\n",
        encoding="utf-8",
    )


def human_prd_missing_brief_sections(case_dir: Path) -> None:
    path = case_dir / "human-prd.md"
    path.write_text(
        "# Human PRD\n\n"
        "Source contract: contract-envelope.json\n\n"
        "render_status.human_prd=review_ready\n\n"
        "## 产品目标\n\n"
        "只写了目标，缺少范围、实现路径、验收、路线图、风险与待确认。\n",
        encoding="utf-8",
    )


def human_prd_contains_agent_only_section(case_dir: Path) -> None:
    path = case_dir / "human-prd.md"
    text = path.read_text(encoding="utf-8")
    text += "\n## Execution Contract\n\nThis agent-only section does not belong in the human brief.\n"
    path.write_text(text, encoding="utf-8")


def human_prd_missing_revision_and_references(case_dir: Path) -> None:
    path = case_dir / "human-prd.md"
    path.write_text(
        "# Human PRD\n\n"
        "Source contract: contract-envelope.json\n\n"
        "Render status: review_ready\n\n"
        "## 产品目标\n\n"
        "做一个工具。\n\n"
        "## 范围\n\n"
        "做核心功能。\n\n"
        "## 实现路径\n\n"
        "按合同执行。\n\n"
        "## 验收\n\n"
        "验收通过即可。\n\n"
        "## 路线图\n\n"
        "先做 MVP。\n\n"
        "## 风险与待确认\n\n"
        "暂无。\n",
        encoding="utf-8",
    )


def gate_object_report_drift(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["GATE-001"]["payload"]["status"] = "blocked"
    contract["objects"]["GATE-001"]["payload"]["blocking"] = True
    write_json(path, contract)


def non_iso_created_at(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["source_idea"]["created_at"] = "not-a-date"
    write_json(path, contract)


def resolved_q_without_resolution(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["Q-001"] = {
        "type": "Q",
        "payload": {
            "id": "Q-001",
            "question": "Resolved without evidence?",
            "blocks_agent_prd": False,
            "status": "resolved",
            "question_type": "boolean",
            "options": ["Yes", "No"],
        },
    }
    contract["open_questions"] = ["Q-001"]
    contract["object_index"]["Q"] = ["Q-001"]
    write_json(path, contract)


def trace_relation_banana(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["TRACE-001"]["payload"]["relation"] = "banana"
    write_json(path, contract)


def missing_harness_workflow_contract(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract.pop("harness_workflow", None)
    write_json(path, contract)


def missing_requirement_table(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract.pop("requirement_table", None)
    write_json(path, contract)


def open_ended_clarification_question(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["objects"]["Q-001"]["payload"]["question_type"] = "open_text"
    contract["objects"]["Q-001"]["payload"]["options"] = []
    write_json(path, contract)


def ready_hld_without_human_prd_approval(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["harness_workflow"]["approval_gates"]["human_prd_review"]["status"] = "pending"
    contract["harness_workflow"]["approval_gates"]["human_prd_review"]["approved_by_ref"] = ""
    write_json(path, contract)


def missing_high_level_design_file(case_dir: Path) -> None:
    (case_dir / "high-level-design.json").unlink()


def missing_high_level_design_markdown_file(case_dir: Path) -> None:
    (case_dir / "high-level-design.md").unlink()


def missing_hld_semantic_review_file(case_dir: Path) -> None:
    (case_dir / "hld-semantic-review.json").unlink()


def hld_missing_required_section(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld.pop("risk_controls", None)
    write_json(path, hld)


def hld_markdown_missing_required_section(case_dir: Path) -> None:
    path = case_dir / "high-level-design.md"
    text = path.read_text(encoding="utf-8")
    start = text.index("## Control Flow")
    end = text.index("## Data Flow")
    path.write_text(text[:start] + text[end:], encoding="utf-8")


def hld_markdown_missing_acceptance_command(case_dir: Path) -> None:
    path = case_dir / "high-level-design.md"
    text = path.read_text(encoding="utf-8")
    text = "\n".join(line for line in text.splitlines() if "Acceptance Command" not in line)
    path.write_text(text + "\n", encoding="utf-8")


def hld_markdown_missing_interface_precision(case_dir: Path) -> None:
    path = case_dir / "high-level-design.md"
    text = path.read_text(encoding="utf-8")
    start = text.index("Source-backed interface precision")
    end = text.index("## State Model")
    path.write_text(text[:start] + text[end:], encoding="utf-8")


def hld_missing_structured_control_flow(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld.pop("control_flow_design", None)
    write_json(path, hld)


def hld_missing_real_acceptance_data(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["real_acceptance_plan"]["real_data"] = ""
    write_json(path, hld)


def hld_deferred_real_acceptance_resources(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["real_acceptance_plan"]["environment"] = "Runtime selected by downstream implementation owner."
    write_json(path, hld)


def hld_missing_acceptance_source_refs(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["real_acceptance_plan"].pop("real_data_source_refs", None)
    write_json(path, hld)


def hld_missing_acceptance_command(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["real_acceptance_plan"].pop("acceptance_command", None)
    write_json(path, hld)


def hld_interface_missing_source_refs(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["interface_contracts"][0].pop("source_refs", None)
    write_json(path, hld)


def hld_interface_loose_invocation(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["interface_contracts"][0]["invocation"] = "Use the interface or equivalent command when needed."
    write_json(path, hld)


def hld_malformed_data_object_field(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["data_objects"][0]["fields"] = ["action"]
    write_json(path, hld)


def hld_generic_design_gate_only(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["design_gate_report"] = [
        {
            "check_id": "CHECK-001",
            "name": "Generic pass",
            "status": "pass",
            "evidence_refs": ["REQ-001"],
            "evidence_summary": "Looks fine.",
            "required_fix": "",
        }
    ]
    write_json(path, hld)


def hld_uses_mock_acceptance(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["real_acceptance_plan"]["execution_steps"] = ["Run the extractor with mock transcript data."]
    write_json(path, hld)


def hld_missing_current_design_refs(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    text = json.dumps(hld, ensure_ascii=False)
    text = text.replace("VER-001", "")
    write_json(path, json.loads(text))


def hld_contains_task_graph(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["task_graph"] = [{"task_id": "TASK-001", "title": "Forbidden task"}]
    write_json(path, hld)


def hld_contains_task_alias(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["tasks"] = [{"task_id": "TASK-001", "title": "Forbidden task alias"}]
    hld["implementation_tasks"] = [{"task_id": "TASK-002", "title": "Forbidden implementation task"}]
    write_json(path, hld)


def hld_warning_gate_without_fix(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["design_gate_report"][0]["status"] = "warning"
    hld["design_gate_report"][0]["message"] = ""
    hld["design_gate_report"][0]["required_fix"] = ""
    write_json(path, hld)


def hld_blocked_gate_without_fix(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    hld = read_json(path)
    hld["design_status"] = "blocked"
    hld["blocking_reasons"] = ["Design gate is blocked."]
    hld["design_gate_report"][0]["status"] = "blocked"
    hld["design_gate_report"][0]["required_fix"] = ""
    write_json(path, hld)


def hld_semantic_review_blocked_dimension(case_dir: Path) -> None:
    path = case_dir / "hld-semantic-review.json"
    review = read_json(path)
    review["review_status"] = "blocked"
    review["dimensions"][0]["status"] = "blocked"
    review["dimensions"][0]["required_fix"] = "Resolve the source traceability blocker."
    write_json(path, review)


def hld_semantic_review_missing_dimension(case_dir: Path) -> None:
    path = case_dir / "hld-semantic-review.json"
    review = read_json(path)
    review["dimensions"] = [
        dimension for dimension in review["dimensions"]
        if dimension.get("dimension_key") != "markdown_parity"
    ]
    write_json(path, review)


def hld_semantic_review_missing_source_refs(case_dir: Path) -> None:
    path = case_dir / "hld-semantic-review.json"
    review = read_json(path)
    for dimension in review["dimensions"]:
        if dimension.get("dimension_key") == "interface_precision":
            dimension["source_refs"] = []
    write_json(path, review)


def legacy_execution_task_plan_present(case_dir: Path) -> None:
    path = case_dir / "execution-task-plan.json"
    path.write_text(
        json.dumps({"plan_id": "PLAN-LEGACY-001", "planning_status": "ready", "task_graph": []}, indent=2)
        + "\n",
        encoding="utf-8",
    )


def missing_interaction_decision(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract.pop("interaction_decision", None)
    write_json(path, contract)


def blocking_question_but_proceed_without_questions(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["interaction_decision"] = {
        "stage": "stage_1_requirements_table",
        "decision": "proceed_without_questions",
        "can_ask_user": True,
        "reason": "Incorrectly proceeds despite an open blocking question.",
        "question_refs": [],
        "blocking_refs": ["Q-001"],
        "source_refs": ["SRC-001"],
    }
    write_json(path, contract)


def open_question_row_without_q_source(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["requirement_table"][0]["origin"] = "open_question"
    contract["requirement_table"][0]["source_refs"] = ["SRC-001"]
    write_json(path, contract)


def assumption_row_without_asm_source(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["requirement_table"][0]["origin"] = "assumption"
    contract["requirement_table"][0]["source_refs"] = ["SRC-001"]
    write_json(path, contract)


def bounded_inference_without_trace(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["requirement_table"][0]["origin"] = "bounded_inference"
    contract["requirement_table"][0]["source_refs"] = ["SRC-001"]
    for trace_id in list(contract.get("traceability", [])):
        payload = contract["objects"][trace_id]["payload"]
        if payload.get("relation") == "inferred_from":
            payload["relation"] = "stated_by"
    write_json(path, contract)


def stage1_with_downstream_artifact(case_dir: Path) -> None:
    path = case_dir / "human-prd.md"
    path.write_text("# Human PRD\n\nThis downstream artifact must not exist in Stage 1.\n", encoding="utf-8")


def stage1_proceeds_without_prd_support(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    core = contract["objects"][contract["core"]]["payload"]
    for key in ("product_name", "one_line_summary", "problem_statement", "value_proposition"):
        core.pop(key, None)
    core["target_users"] = []
    core["personas"] = []
    contract["scope"].pop("mvp_boundary", None)
    write_json(path, contract)


def stage1_execution_like_without_implementation_topology(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["implementation_model"]["control_flow"] = []
    contract["implementation_model"]["modules"] = []
    contract["implementation_model"]["technical_decisions"] = []
    write_json(path, contract)


def stage2_with_hld_artifact(case_dir: Path) -> None:
    path = case_dir / "high-level-design.json"
    path.write_text(json.dumps({"design_status": "ready"}, indent=2) + "\n", encoding="utf-8")


def stage2_prd_only_package(case_dir: Path) -> None:
    for filename in ("high-level-design.json", "high-level-design.md"):
        path = case_dir / filename
        if path.exists():
            path.unlink()
    semantic_review_path = case_dir / "hld-semantic-review.json"
    if semantic_review_path.exists():
        semantic_review_path.unlink()
    acceptance_dir = case_dir / "acceptance"
    if acceptance_dir.exists():
        shutil.rmtree(acceptance_dir)

    contract_path = case_dir / "contract-envelope.json"
    contract = read_json(contract_path)
    objects = contract.get("objects", {})
    for source_id in ("SRC-007", "SRC-008", "SRC-009"):
        objects.pop(source_id, None)
    sources = contract.get("sources")
    if isinstance(sources, list):
        contract["sources"] = [
            source for source in sources
            if (
                source.get("source_id")
                if isinstance(source, dict)
                else source
            ) not in {"SRC-007", "SRC-008", "SRC-009"}
        ]
    source_index = contract.get("object_index", {}).get("SRC")
    if isinstance(source_index, list):
        contract["object_index"]["SRC"] = [source_id for source_id in source_index if source_id not in {"SRC-007", "SRC-008", "SRC-009"}]

    workflow = contract.setdefault("harness_workflow", {})
    workflow["current_stage"] = "stage_2_prd_review"
    workflow["completed_stages"] = ["stage_1_requirements_table"]
    approvals = workflow.setdefault("approval_gates", {})
    approvals["human_prd_review"] = {"status": "pending", "approved_by_ref": ""}
    summary = contract.setdefault("contract_summary", {})
    summary["stage_ready"] = ["stage_1_requirements_table", "stage_2_prd_review"]
    summary["stage_blocked"] = ["stage_3_hld"]
    contract["next_actions"] = [
        "Review human-prd.md. If approved, record a user_confirmation SRC and run Stage 3 HLD."
    ]
    write_json(contract_path, contract)


def stage2_agent_prd_thin_sections(case_dir: Path) -> None:
    path = case_dir / "agent-prd.md"
    sections = [
        "Document Metadata",
        "Executive Summary",
        "Problem and Background",
        "Target Users and Personas",
        "Goals and Outcomes",
        "Success Metrics",
        "Scope and Non-Goals",
        "User Stories and Use Cases",
        "Functional Requirements",
        "Non-Functional Requirements and Guardrails",
        "User Flow or UX Notes",
        "Acceptance Criteria",
        "Release Plan and Roadmap",
        "Risks, Assumptions, and Dependencies",
        "Open Questions",
        "Traceability",
        "Source of Truth",
        "Reader and Mission",
        "Requirement Trace",
        "Input Contract",
        "Execution Contract",
        "Tool and Integration Boundaries",
        "Permissions and Safety",
        "Data and State Contract",
        "Verification Contract",
        "Output Contract",
        "Stop Conditions",
        "Done Criteria",
        "Forbidden Assumptions",
    ]
    body = "# Thin Agent PRD\n\nSource contract: `contract-envelope.json`\n\nrender_status.agent_prd=execution_ready\n\n"
    body += "\n\n".join(f"## {section}\n\nREQ-001" for section in sections)
    path.write_text(body + "\n", encoding="utf-8")


def stage2_human_prd_thin_sections(case_dir: Path) -> None:
    path = case_dir / "human-prd.md"
    path.write_text(
        "# Thin Human PRD\n\n"
        "## 修订记录\n\n"
        "| 版本 | 日期 | 修订说明 | 修订人 |\n"
        "| --- | --- | --- | --- |\n"
        "| v1.0 | 2026-05-27 | 简报。 | Agent |\n\n"
        "## 产品目标\n\n[REQ-001]\n\n"
        "## 建设范围\n\n[REQ-001]\n\n"
        "## 实现方案\n\n[REQ-001]\n\n"
        "## 验收标准与方法\n\n[AC-001]\n\n"
        "## 路线图\n\n[PHASE-001]\n\n"
        "## 风险与待确认\n\n[RISK-001]\n\n"
        "## 参考文献\n\n- `contract-envelope.json`\n- [REQ-001]\n",
        encoding="utf-8",
    )


def stage2_summary_drift(case_dir: Path) -> None:
    path = case_dir / "contract-envelope.json"
    contract = read_json(path)
    contract["contract_summary"]["stage_ready"] = ["stage_1_requirements_table"]
    contract["contract_summary"]["stage_blocked"] = []
    write_json(path, contract)


def stage2_agent_prd_missing_implementation_refs(case_dir: Path) -> None:
    path = case_dir / "agent-prd.md"
    text = path.read_text(encoding="utf-8")
    for ref in ("FLOW-001", "DATA-001", "MOD-001", "MOD-002", "MOD-003", "TECH-001", "TECH-002", "DCT-001"):
        text = text.replace(ref, "")
    path.write_text(text, encoding="utf-8")


def main() -> int:
    shutil.rmtree(TMP, ignore_errors=True)
    TMP.mkdir(parents=True, exist_ok=True)
    try:
        checks: list[tuple[str, Path, bool]] = [
            ("blocked fixture passes", BASE_BLOCKED, True),
            ("ready fixture passes", BASE_READY, True),
            ("noncanonical_object_namespace fails", make_case("noncanonical_object_namespace", noncanonical_object_namespace), False),
            ("requested_agent_prd_without_render_block fails", make_case("requested_agent_prd_without_render_block", requested_agent_prd_without_render_block), False),
            ("ready_hld_from_draft_agent_prd fails", make_case("ready_hld_from_draft_agent_prd", ready_hld_from_draft_agent_prd, BASE_READY), False),
            ("invalid_object_statuses fails", make_case("invalid_object_statuses", invalid_object_statuses, BASE_READY), False),
            ("render_block_wrong_source_ref_type fails", make_case("render_block_wrong_source_ref_type", render_block_wrong_source_ref_type, BASE_READY), False),
            ("contract_summary_drift fails", make_case("contract_summary_drift", contract_summary_drift, BASE_READY), False),
            ("traceability_summary_decision_wrong_type fails", make_case("traceability_summary_decision_wrong_type", traceability_summary_decision_wrong_type, BASE_READY), False),
            ("object_index_drift fails", make_case("object_index_drift", object_index_drift, BASE_READY), False),
            ("core_blocked_ready fails", make_case("core_blocked_ready", core_blocked_ready, BASE_READY), False),
            ("stop_triggered_ready fails", make_case("stop_triggered_ready", stop_triggered_ready, BASE_READY), False),
            ("blocking_q_missing_status fails", make_case("blocking_q_missing_status", blocking_q_missing_status, BASE_READY), False),
            ("user_confirmation_decision_ref passes", make_case("user_confirmation_decision_ref", user_confirmation_decision_ref, BASE_READY), True),
            ("agent_prd_missing_required_sections fails", make_case("agent_prd_missing_required_sections", agent_prd_missing_required_sections, BASE_READY), False),
            ("agent_prd_execution_contract_only fails", make_case("agent_prd_execution_contract_only", agent_prd_execution_contract_only, BASE_READY), False),
            ("human_prd_missing_brief_sections fails", make_case("human_prd_missing_brief_sections", human_prd_missing_brief_sections, BASE_READY), False),
            ("human_prd_contains_agent_only_section fails", make_case("human_prd_contains_agent_only_section", human_prd_contains_agent_only_section, BASE_READY), False),
            ("human_prd_missing_revision_and_references fails", make_case("human_prd_missing_revision_and_references", human_prd_missing_revision_and_references, BASE_READY), False),
            ("gate_object_report_drift fails", make_case("gate_object_report_drift", gate_object_report_drift, BASE_READY), False),
            ("non_iso_created_at fails", make_case("non_iso_created_at", non_iso_created_at, BASE_READY), False),
            ("resolved_q_without_resolution fails", make_case("resolved_q_without_resolution", resolved_q_without_resolution, BASE_READY), False),
            ("trace_relation_banana fails", make_case("trace_relation_banana", trace_relation_banana, BASE_READY), False),
            ("missing_harness_workflow_contract fails", make_case("missing_harness_workflow_contract", missing_harness_workflow_contract, BASE_READY), False),
            ("missing_requirement_table fails", make_case("missing_requirement_table", missing_requirement_table, BASE_READY), False),
            ("open_ended_clarification_question fails", make_case("open_ended_clarification_question", open_ended_clarification_question, BASE_BLOCKED), False),
            ("ready_hld_without_human_prd_approval fails", make_case("ready_hld_without_human_prd_approval", ready_hld_without_human_prd_approval, BASE_READY), False),
            ("missing_high_level_design_file fails", make_case("missing_high_level_design_file", missing_high_level_design_file, BASE_READY), False),
            ("missing_high_level_design_markdown_file fails", make_case("missing_high_level_design_markdown_file", missing_high_level_design_markdown_file, BASE_READY), False),
            ("missing_hld_semantic_review_file fails", make_case("missing_hld_semantic_review_file", missing_hld_semantic_review_file, BASE_READY), False),
            ("hld_missing_required_section fails", make_case("hld_missing_required_section", hld_missing_required_section, BASE_READY), False),
            ("hld_markdown_missing_required_section fails", make_case("hld_markdown_missing_required_section", hld_markdown_missing_required_section, BASE_READY), False),
            ("hld_markdown_missing_acceptance_command fails", make_case("hld_markdown_missing_acceptance_command", hld_markdown_missing_acceptance_command, BASE_READY), False),
            ("hld_markdown_missing_interface_precision fails", make_case("hld_markdown_missing_interface_precision", hld_markdown_missing_interface_precision, BASE_READY), False),
            ("hld_missing_structured_control_flow fails", make_case("hld_missing_structured_control_flow", hld_missing_structured_control_flow, BASE_READY), False),
            ("hld_missing_real_acceptance_data fails", make_case("hld_missing_real_acceptance_data", hld_missing_real_acceptance_data, BASE_READY), False),
            ("hld_deferred_real_acceptance_resources fails", make_case("hld_deferred_real_acceptance_resources", hld_deferred_real_acceptance_resources, BASE_READY), False),
            ("hld_missing_acceptance_source_refs fails", make_case("hld_missing_acceptance_source_refs", hld_missing_acceptance_source_refs, BASE_READY), False),
            ("hld_missing_acceptance_command fails", make_case("hld_missing_acceptance_command", hld_missing_acceptance_command, BASE_READY), False),
            ("hld_interface_missing_source_refs fails", make_case("hld_interface_missing_source_refs", hld_interface_missing_source_refs, BASE_READY), False),
            ("hld_interface_loose_invocation fails", make_case("hld_interface_loose_invocation", hld_interface_loose_invocation, BASE_READY), False),
            ("hld_malformed_data_object_field fails", make_case("hld_malformed_data_object_field", hld_malformed_data_object_field, BASE_READY), False),
            ("hld_generic_design_gate_only fails", make_case("hld_generic_design_gate_only", hld_generic_design_gate_only, BASE_READY), False),
            ("hld_uses_mock_acceptance fails", make_case("hld_uses_mock_acceptance", hld_uses_mock_acceptance, BASE_READY), False),
            ("hld_missing_current_design_refs fails", make_case("hld_missing_current_design_refs", hld_missing_current_design_refs, BASE_READY), False),
            ("hld_contains_task_graph fails", make_case("hld_contains_task_graph", hld_contains_task_graph, BASE_READY), False),
            ("hld_contains_task_alias fails", make_case("hld_contains_task_alias", hld_contains_task_alias, BASE_READY), False),
            ("hld_warning_gate_without_fix fails", make_case("hld_warning_gate_without_fix", hld_warning_gate_without_fix, BASE_READY), False),
            ("hld_blocked_gate_without_fix fails", make_case("hld_blocked_gate_without_fix", hld_blocked_gate_without_fix, BASE_READY), False),
            ("hld_semantic_review_blocked_dimension fails", make_case("hld_semantic_review_blocked_dimension", hld_semantic_review_blocked_dimension, BASE_READY), False),
            ("hld_semantic_review_missing_dimension fails", make_case("hld_semantic_review_missing_dimension", hld_semantic_review_missing_dimension, BASE_READY), False),
            ("hld_semantic_review_missing_source_refs fails", make_case("hld_semantic_review_missing_source_refs", hld_semantic_review_missing_source_refs, BASE_READY), False),
            ("legacy_execution_task_plan_present fails", make_case("legacy_execution_task_plan_present", legacy_execution_task_plan_present, BASE_READY), False),
            ("missing_interaction_decision fails", make_case("missing_interaction_decision", missing_interaction_decision, BASE_READY), False),
            ("blocking_question_but_proceed_without_questions fails", make_case("blocking_question_but_proceed_without_questions", blocking_question_but_proceed_without_questions, BASE_BLOCKED), False),
            ("open_question_row_without_q_source fails", make_case("open_question_row_without_q_source", open_question_row_without_q_source, BASE_BLOCKED), False),
            ("assumption_row_without_asm_source fails", make_case("assumption_row_without_asm_source", assumption_row_without_asm_source, BASE_READY), False),
            ("bounded_inference_without_trace fails", make_case("bounded_inference_without_trace", bounded_inference_without_trace, BASE_READY), False),
        ]
        stage1_checks: list[tuple[str, Path, bool]] = [
            ("stage1 live contract passes", STAGE1_LIVE, True),
            ("stage1 downstream artifact fails", make_case("stage1_with_downstream_artifact", stage1_with_downstream_artifact, STAGE1_LIVE), False),
            ("stage1 proceeds without PRD support fails", make_case("stage1_proceeds_without_prd_support", stage1_proceeds_without_prd_support, STAGE1_LIVE), False),
            ("stage1 execution-like without implementation topology fails", make_case("stage1_execution_like_without_implementation_topology", stage1_execution_like_without_implementation_topology, STAGE1_LIVE), False),
        ]
        stage2_base = make_case("stage2_prd_only_base", stage2_prd_only_package, STAGE2_LIVE)
        stage2_checks: list[tuple[str, Path, bool]] = [
            ("stage2 live PRD package passes", stage2_base, True),
            ("stage2 HLD artifact fails", make_case("stage2_with_hld_artifact", stage2_with_hld_artifact, stage2_base), False),
            ("stage2 thin agent PRD fails", make_case("stage2_agent_prd_thin_sections", stage2_agent_prd_thin_sections, stage2_base), False),
            ("stage2 thin human PRD fails", make_case("stage2_human_prd_thin_sections", stage2_human_prd_thin_sections, stage2_base), False),
            ("stage2 summary drift fails", make_case("stage2_summary_drift", stage2_summary_drift, stage2_base), False),
            ("stage2 agent PRD missing implementation refs fails", make_case("stage2_agent_prd_missing_implementation_refs", stage2_agent_prd_missing_implementation_refs, stage2_base), False),
        ]

        failures: list[str] = []
        results: list[dict] = []
        for name, case_dir, should_pass in checks:
            code, payload = run_validator(case_dir)
            passed = code == 0 and payload.get("ok") is True
            results.append({"name": name, "passed": passed, "errors": payload.get("errors", [])})
            if passed != should_pass:
                failures.append(f"{name}: expected pass={should_pass}, got pass={passed}")
        for name, case_dir, should_pass in stage1_checks:
            code, payload = run_validator(case_dir, stage="stage1")
            passed = code == 0 and payload.get("ok") is True
            results.append({"name": name, "passed": passed, "errors": payload.get("errors", [])})
            if passed != should_pass:
                failures.append(f"{name}: expected pass={should_pass}, got pass={passed}")
        for name, case_dir, should_pass in stage2_checks:
            code, payload = run_validator(case_dir, stage="stage2")
            passed = code == 0 and payload.get("ok") is True
            results.append({"name": name, "passed": passed, "errors": payload.get("errors", [])})
            if passed != should_pass:
                failures.append(f"{name}: expected pass={should_pass}, got pass={passed}")

        print(json.dumps({"ok": not failures, "failures": failures, "results": results}, ensure_ascii=False, indent=2))
        return 0 if not failures else 1
    finally:
        shutil.rmtree(TMP, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
