# Spec Intake Workflow

## Harness Type

`spec-intake` is a review-gated, self-improving generation harness.

## Stage 1: Requirement Table Intake

Input:
- raw user idea
- optional notes, files, constraints, or prior PRD fragments

Actions:
- register source facts as `SRC-*`
- classify extracted statements as explicit facts, confirmed facts, bounded inferences, assumptions, or open questions
- write `interaction_decision` as `ask_user`, `proceed_without_questions`, or `blocked_draft`
- ask only boolean, single-choice, or multi-choice clarification questions when readiness blockers remain and the decision is `ask_user`
- collect or block on the PRD-ready support needed by Stage 2: product context, target-user posture, MVP boundary, acceptance and verification method, implementation approach, roadmap, risks/open decisions, sources, and agent execution refs
- for execution-like ideas, collect or block on execution topology: external components, authoritative component sources, public interface boundary, execution loop, state handling, subjective judgment boundary, evidence chain, and mechanical delivery checks
- write `contract-envelope.json.requirement_table`

Output:
- Stage 1 package rooted at `contract-envelope.json`
- canonical contract objects
- interaction decision with source, question, and blocker refs
- structured requirement table
- PRD-ready Stage 1 support when `interaction_decision=proceed_without_questions`
- blocked/draft gates when information is incomplete

Delivery:
- Stage 1 is complete only after `contract-envelope.json` is written as a real file and `skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage1` passes.
- Stage 1 must not output `human-prd.md`, `agent-prd.md`, `high-level-design.json`, `high-level-design.md`, `hld-semantic-review.json`, or `execution-task-plan.json`.

Gate:
- pass when current-phase requirements have traceable rows, `interaction_decision` has no undeclared blockers, and `proceed_without_questions` has PRD-ready support for Stage 2
- for execution-like ideas, pass only when control flow, modules, and technical decisions are present and source-backed enough to render implementation approach without inventing component capabilities
- blocked when material product, execution, permission, verification, stop, or done facts are unknown

## Stage 2: PRD Rendering And Human Review

Input:
- Stage 1 requirement table
- canonical contract objects

Actions:
- render `agent-prd.md` in English as the execution-ready PRD from the same contract: full PRD body plus agent execution appendix
- render `human-prd.md` in professional Simplified Chinese as a concise, formal, evidence-backed human review brief with revision record, product goal, construction scope, implementation approach, acceptance criteria and methods, roadmap, risks/open decisions, and references
- present Human PRD for user review

Delivery:
- Agent PRD must define product metadata, summary, problem/background, users/personas, goals/outcomes, success metrics, scope/non-goals, user stories/use cases, functional and non-functional requirements, user flow/UX notes, acceptance criteria, release plan/roadmap, risks/assumptions/dependencies, open questions, traceability, and an agent execution appendix covering source of truth, mission, input, execution, tool/integration boundaries, permissions/safety, data/state, verification, output, stop, done, and forbidden assumptions.
- Agent PRD required sections must contain non-trivial body text and visibly cover current-phase `REQ`, `AC`, `VER`, `IN`, `EXE`, `OUT`, `STOP`, and `DONE` refs.
- Agent PRD must visibly cover non-empty implementation-model refs such as `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, and `DCT` so execution topology does not disappear during rendering.
- Human PRD must stay brief and cover product goal, scope, implementation path, acceptance, roadmap, and risks/open decisions.
- Human PRD implementation path must contain concrete reviewable content, including key external components, major execution loop, judgment/check boundaries, and verification method when those are present in the contract.
- Human PRD core sections must contain concrete reviewable content, not only headings or canonical citations.
- Both PRDs must be derived from the Stage 1 requirement table and canonical objects; missing facts route back to Stage 1.
- Stage 2 is complete only after `skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage2` passes.

Routes:
- `approved`: record a `SRC.source_type=user_confirmation` and proceed to Stage 3
- `revise`: update the requirement table first, rerender PRDs, and repeat Stage 2
- `failed`: stop with blocked status and required fixes

Output:
- Human PRD
- Agent PRD
- Human PRD review gate state

Gate:
- ready when both PRDs validate, `human_prd_review.status` is `pending` or `approved`, and no HLD or task-plan artifact exists in the Stage 2 package
- ready when `contract_summary.stage_ready` includes Stage 1 and Stage 2, Stage 3 is not ready, and pending Human PRD review keeps Stage 3 blocked
- blocked when PRD content is thin, unsupported, untraceable, or the Human PRD review gate state is inconsistent

## Stage 3: HLD

Input:
- approved Human PRD evidence
- execution-ready Agent PRD
- Stage 1 requirement table
- canonical contract objects

Actions:
- create `high-level-design.json` as the structured HLD source, `high-level-design.md` as the formal HLD document, and `hld-semantic-review.json` as the independent semantic review artifact
- write architecture summary, component boundaries, data/state design, integration points, verification strategy, and risk controls
- write structured implementation design: control flow, data flow, data objects, source-backed interface contracts, state model, technical decisions, implementation design, environment requirements, and executable real acceptance plan
- render the formal HLD document with revision history, scope/goals, architecture overview, control flow, data flow, data objects, interface contracts, state model, technical decisions, implementation design, real acceptance plan, risks/guardrails, references, diagrams, tables, and canonical refs
- when environment, real data, interface documentation, permissions, deployment constraints, acceptance owner, or other HLD-required information is missing, ask the user for that information or produce a blocked HLD with required fixes
- prove HLD readiness through fixed design gates covering source readiness, control flow, data/data objects, interface/state, technical implementation, real acceptance, HLD document readiness, and task boundary; then prove independent semantic review readiness through fixed dimensions

Output:
- ready or blocked `high-level-design.json`
- ready or blocked `high-level-design.md`
- ready or blocked `hld-semantic-review.json`
- design gate report

Gate:
- ready only when the Human PRD review gate is approved, the Agent PRD is execution-ready, all HLD files are present, HLD facts are contract-backed, required implementation design sections are structured and non-empty, interface contracts have exact invocation boundaries and `SRC-*` source evidence, `high-level-design.md` contains the required HLD sections plus diagrams/tables/current refs/source-backed interface precision/executable acceptance design, current requirement/execution/implementation refs are covered, concrete real-environment and real-data acceptance is defined with executable command, preconditions, expected artifacts, mechanical checks, failure criteria, `SRC-*` evidence refs, and no mock or deferred content, all required HLD design gate keys including `hld_document_readiness` are present and pass, `hld-semantic-review.json` has `review_status=pass` and all required dimensions pass, no task-plan artifact exists, and validator passes
- blocked when control flow, data flow, data objects, interface contracts, state model, technical decisions, implementation details, real environment, real data, or acceptance evidence are missing or unsupported

## Retry And Exhaustion

Revision loops route back to Stage 1 because feedback changes the requirement table before PRDs or HLD are regenerated. The default maximum review loop count is 3. When the loop exhausts, produce a blocked package with unresolved questions and required fixes.

## Handoff

The final handoff must state package path, stage status, ready/blocked targets, validator command, validator verdict, semantic review verdict, and remaining risks.
