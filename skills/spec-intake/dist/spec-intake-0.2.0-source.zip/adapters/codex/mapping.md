# Codex Adapter Mapping

## Portable Core To Runtime

- `agent.md` maps to the role and completion criteria in `skill/SKILL.md`.
- `workflow.md` maps to the staged execution instructions in `skill/SKILL.md`.
- `rules.md` maps to hard rules and completion checks in `skill/SKILL.md`.
- `schemas/contract-envelope.schema.md` maps to validator-backed package structure.

## Runtime Files

- Source adapter entry: `adapters/codex/SKILL.md`
- Installable Codex skill entry: `skill/SKILL.md`
- OpenAI metadata: `skill/agents/openai.yaml`
- Runtime references: `skill/references/*.md`
- Runtime validators: `skill/scripts/*.py`

## Unsupported Or Degraded Behavior

Codex cannot force a user to approve a Human PRD in a separate UI state. The adapter records approval as `SRC.source_type=user_confirmation`; without that source ref, the validator blocks ready Stage 3 HLD.

## Adapter Faithfulness Checks

- The adapter must mention the three canonical stages.
- The adapter must preserve the Stage 1 `interaction_decision` gate.
- The adapter must preserve closed-form clarification questions.
- The adapter must preserve the Human PRD approval gate.
- The adapter must preserve requirement-table derivation for PRDs and HLD.
- The adapter must preserve ready HLD implementation-design and no-mock real-acceptance gates.
- The adapter must forbid task-plan output.
