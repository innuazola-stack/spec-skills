# PRD Quality Reference

Use this reference during Stage 2 to calibrate PRD depth, traceability, and review usefulness after Stage 1 has produced a validator-clean `contract-envelope.json`.

This is a quality reference, not a product template and not a source of domain facts.

## Reference Package

The repository includes a real Stage 2 package that reached the intended quality bar:

`tests/live-runs/2026-05-27/executor-minimal-stage2/`

Primary artifacts:

- `contract-envelope.json`: canonical requirement table, sources, implementation model, gates, and traceability.
- `agent-prd.md`: English execution-ready PRD for downstream agents.
- `human-prd.md`: Simplified Chinese human review brief.
- `intake-notes.md`: intake audit notes.

Use this package to understand the expected level of specificity and evidence discipline. Do not copy executor-specific facts, component names, method names, CLI names, or domain wording into unrelated products.

## What To Learn From The Reference

### Contract-First Revision

Late user feedback became canonical contract facts before the PRDs were rewritten. New external sources, requirements, acceptance criteria, verification refs, risks, and traceability rows were added to `contract-envelope.json` first. The PRDs then rendered those facts.

Quality bar: no important PRD claim should exist only in prose.

### Source-Backed Implementation Detail

The reference does not say "call an adapter" generically when source material exists. It records the external component source, public method or command boundary, runtime states, screen/status evidence, judgment boundary, and delivery-check boundary in the contract before describing the implementation approach in the PRDs.

Quality bar: when external component docs or source are available, method-level or interface-level claims must cite canonical source refs. When sources are missing, record a blocking question or assumption instead of inventing the interface.

### Execution-Ready Agent PRD

The Agent PRD is a complete product requirements document plus an agent execution appendix. It explains the problem, target users, goals, success measures, scope, requirements, acceptance, verification, roadmap, risks, assumptions, dependencies, and traceability. It also gives downstream agents the input, execution, integration, permission, state, output, stop, and done contracts.

Quality bar: another agent should be able to proceed to HLD without asking "what is the product?", "how does execution actually work?", or "how will we know it is acceptable?"

### Human PRD With Review Value

The Human PRD is short, formal, and review-oriented, but not empty. It starts with a revision table, uses Simplified Chinese, answers what the product goal is, what will be built, how it will work, how it will be accepted, what the roadmap is, and what risks remain. It uses structured forms such as tables or Mermaid diagrams when they improve readability, and ends with references.

Quality bar: a human reviewer should understand the product direction and approval risks without reading the Agent PRD.

### Execution Topology Visibility

For execution-like products, both PRDs expose the material topology: external components, public interfaces, loop or orchestration model, runtime states, evidence outputs, subjective judgment owner, mechanical checks, and final acceptance owner.

Quality bar: do not hide a material execution loop behind vague implementation phrases.

## Forbidden Uses

- Do not treat this reference as a template that every product must mimic section-by-section.
- Do not import executor-specific requirements, component names, methods, CLI names, monitoring behavior, or delivery checks into other products.
- Do not use the reference as evidence for the current product. Current-product facts must come from the current Stage 1 sources and requirement table.
- Do not use the reference to bypass user clarification when the current product lacks required facts.

## Stage 2 Self-Check

Before marking PRDs `review_ready` or `execution_ready`, compare the draft with the reference quality bar:

- Does every material product or implementation claim trace to the current `contract-envelope.json`?
- Does the Agent PRD read as a complete PRD, not only an agent instruction sheet?
- Does the Agent PRD render non-empty `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, and `DCT` refs when present?
- Does the Human PRD answer goal, scope, approach, acceptance method, roadmap, and risks with concrete information?
- Could a human approve the direction from the Human PRD without opening the Agent PRD?
- Could a downstream agent begin HLD from the Agent PRD without guessing key execution boundaries?
- Has revision feedback been incorporated through the requirement table before rerendering the PRDs?

If the draft fails these checks, return to Stage 1 or revise the contract-backed Stage 2 render before presenting it as ready.
