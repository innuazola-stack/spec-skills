# Output Artifacts

Use this reference before writing `contract-envelope.json`, `human-prd.md`, `agent-prd.md`, `high-level-design.json`, or `high-level-design.md`.

## Package Files

Stage 1 package:

```text
contract-envelope.json
```

Stage 1 is complete only when this file is written and `validate_spec_intake_package.py <output-dir> --stage stage1` passes. Stage 1 packages must not contain `human-prd.md`, `agent-prd.md`, `high-level-design.json`, `high-level-design.md`, `hld-semantic-review.json`, or `execution-task-plan.json`.

Stage 2 package:

```text
contract-envelope.json
human-prd.md
agent-prd.md
intake-notes.md
```

Stage 2 is complete only when these files are written and `validate_spec_intake_package.py <output-dir> --stage stage2` passes. Stage 2 packages must not contain `high-level-design.json`, `high-level-design.md`, `hld-semantic-review.json`, or `execution-task-plan.json`. `render_status.human_prd` must be `review_ready`, `render_status.agent_prd` must be `execution_ready`, `harness_workflow.current_stage` must be `stage_2_prd_review`, and `human_prd_review.status` must be `pending` or `approved`. `contract_summary.stage_ready` must include Stage 1 and Stage 2, must not include Stage 3, and pending Human PRD review must keep Stage 3 blocked.

Final package:

```text
contract-envelope.json
human-prd.md
agent-prd.md
high-level-design.json
high-level-design.md
hld-semantic-review.json
intake-notes.md
```

The package is a file-based adaptation of `docs/prd-intake/output-contract.md`: `contract-envelope.json` is the canonical contract plus audit layer, `human-prd.md` and `agent-prd.md` are sibling renders from that contract, `high-level-design.json` is the structured HLD source, `high-level-design.md` is the formal human-readable HLD document, and `hld-semantic-review.json` is the independent semantic review artifact.

## Contract Envelope

`contract-envelope.json` is the source of truth. It must contain:

- `contract_version`
- `intake_id`
- `harness_workflow`
- `source_idea`
- `interaction_decision`
- `requirement_table`
- `core`
- `scope`
- `requirements`
- `acceptance_criteria`
- `success_metrics`
- `implementation_model`
- `agent_execution`
- `risks`
- `quality_bars`
- `assumptions`
- `open_questions`
- `references`
- `sources`
- `traceability`
- `render_blocks`
- `document_metadata`
- `quality_gates`
- `render_status`
- `objects`
- `object_index`
- `contract_summary`
- `traceability_summary`
- `gate_report`
- `next_actions`

Use canonical IDs: `CORE`, `USER`, `SCOPE`, `OOS`, `PHASE`, `REQ`, `AC`, `MET`, `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, `DCT`, `IN`, `EXE`, `VER`, `OUT`, `STOP`, `DONE`, `RISK`, `BAR`, `ASM`, `Q`, `REF`, `SRC`, `TRACE`, `RB`, `META`, `GATE`.

Top-level arrays are indexes or views. `objects[ID].payload` owns the facts. `object_index` is derived from `objects` and must cover every object by canonical type.

Every top-level view must match its object type exactly. For example, every `REQ-*` object appears in `requirements`, every `GATE-*` object appears in `quality_gates` and `gate_report`, and every `SRC-*` object appears in `sources`. Do not hide canonical objects only in `objects`.

## Harness Workflow State

`harness_workflow.workflow_type` must be `review_gated_self_improving_generation`.

`harness_workflow.stage_order` must be:

1. `stage_1_requirements_table`
2. `stage_2_prd_review`
3. `stage_3_hld`

`harness_workflow.approval_gates.human_prd_review` controls the Stage 2 to Stage 3 transition. Stage 3 may run only when:

- `status=approved`
- `approved_by_ref` points to a `SRC-*` object
- that `SRC-*` has `source_type=user_confirmation`

When the user rejects or revises the Human PRD, set the approval gate to `revise`, update the requirement table, and rerender PRDs before any HLD.

## Interaction Decision

`interaction_decision` is the hard Stage 1 route decision. It records whether the workflow must ask the user, can proceed without questions, or can only produce a blocked draft.

Required fields:

- `stage=stage_1_requirements_table`
- `decision`: `ask_user`, `proceed_without_questions`, or `blocked_draft`
- `can_ask_user`
- `reason`
- `question_refs`
- `blocking_refs`
- `source_refs`

`decision=ask_user` requires non-empty `question_refs` backed by `Q-*` objects. `decision=proceed_without_questions` is forbidden while unresolved blocking `Q-*`, `ASM-*`, triggered `STOP-*`, or blocking `GATE-*` refs remain.

`decision=proceed_without_questions` also requires PRD-ready Stage 1 support. The contract must already contain source-backed product context, target-user posture, MVP boundary, current-phase requirement rows, acceptance/verification support, implementation approach support, and complete agent execution refs (`IN`, `EXE`, `VER`, `OUT`, `STOP`, `DONE`). Missing support must route to `ask_user` or `blocked_draft`.

## Requirement Table

`requirement_table` is the Stage 1 canonical table consumed by every later stage. Every current-phase `REQ-*` must have one row with:

- `row_id`
- `requirement_ref`
- `origin`
- `source_refs`
- `problem`
- `user_value`
- `mvp_scope`
- `acceptance_summary`
- `target_artifact_refs`

Allowed `origin` values are `explicit_fact`, `confirmed_fact`, `bounded_inference`, `assumption`, and `open_question`. `source_refs` must be non-empty and trace to `SRC-*`, `ASM-*`, or `Q-*`. `explicit_fact` and `confirmed_fact` require `SRC-*`; `assumption` requires `ASM-*`; `open_question` requires `Q-*`; `bounded_inference` requires `SRC-*` and `TRACE.relation=inferred_from` to the row requirement. Ready outputs are forbidden when important rows depend on unresolved open questions or material assumptions.

## Source Facts

Every rendered fact must trace to `SRC-*`, `ASM-*`, `Q-*`, or another canonical object.

`SRC.source_type` must be one of:

- `user_input`
- `user_document`
- `user_confirmation`
- `external_reference`
- `local_file`
- `runtime_input`
- `system_generated`

For `user_input`, `user_document`, and `user_confirmation`, include `content` or `target`. Do not write "user confirmed" only in prose; record a `SRC.source_type=user_confirmation` object and link it through `TRACE` or `decision_traceability`.

## Status Rules

- Human PRD statuses: `not_requested`, `draft`, `review_ready`, `blocked`.
- Agent PRD statuses: `not_requested`, `draft`, `execution_ready`, `blocked`.
- `CORE` and `REQ`: `draft`, `confirmed`, `blocked`.
- `Q` and `ASM`: `open`, `resolved`, `deferred`, `superseded`.
- `RB`: `ready`, `blocked`.
- `STOP`: `defined`, `triggered`, `resolved`.
- `GATE`: `pass`, `warning`, `blocked`.

Do not add `status` to object types that do not define it.

## Readiness Blockers

Ready output is forbidden when:

- `CORE.status=blocked`
- any current `REQ.status=blocked`
- `Q` or `ASM` has `blocks_human_prd=true` or `blocks_agent_prd=true` and `status` is missing or `open`
- `STOP.status=triggered` affects Agent PRD execution
- `GATE.status=blocked` or `GATE.blocking=true` affects the target
- `gate_report.status=warning` lacks `message` or `required_fix`
- `gate_report.status=pass|warning` has `blocking=true`
- `gate_report.blocking=true` has any status other than `blocked`

`contract_summary.ready_targets` and `blocked_targets` must be derived from these blockers, not written by hand.

Current requirements are phase-aware. The current phase is the first canonical `PHASE-*` in `scope.roadmap` unless the HLD provides a more specific canonical phase. Future-phase blocked requirements must not block the current phase, and future-phase requirements must not enter a ready current-phase HLD.

## Human PRD

Render in professional, formal Simplified Chinese as a concise human review brief. A review-ready Human PRD must include:

- 修订记录
- 产品目标：为什么做、给谁用、解决什么问题
- 建设范围：MVP 做什么、不做什么
- 实现方案：关键组件、关键流程、关键约束如何组合成可交付产品
- 验收标准与方法：验收标准是什么，用什么方法证明通过
- 路线图：当前阶段交付什么，后续内容如何处理
- 风险与待确认：阻塞、假设、开放问题、审批事项
- 参考文献

The Human PRD is for decision-making. It may be `draft` or `review_ready`; it is not an implementation task list and not a full Agent PRD. Keep it concise but information-dense. It must not include workflow process markers such as `Source contract:`, `Render status:`, or `render_status`. Every substantive section must cite canonical refs, the revision table must be first, and references must be last.

Review-ready Human PRD sections must not be heading-only or citation-only. Product goal, construction scope, implementation approach, acceptance criteria and methods, roadmap, and risks/open decisions must each contain concrete reviewable content plus canonical refs.

## Agent PRD

Render in English as the complete PRD for another agent. An execution-ready Agent PRD must be a real product requirements document plus a traceable agent execution appendix.

The Product PRD body must define:

- Document Metadata
- Executive Summary
- Problem and Background
- Target Users and Personas
- Goals and Outcomes
- Success Metrics
- Scope and Non-Goals
- User Stories and Use Cases
- Functional Requirements
- Non-Functional Requirements and Guardrails
- User Flow or UX Notes
- Acceptance Criteria
- Release Plan and Roadmap
- Risks, Assumptions, and Dependencies
- Open Questions
- Traceability

The Agent Execution Appendix must define:

- Source of Truth
- Reader and Mission
- Requirement Trace
- Input Contract
- Execution Contract
- Tool and Integration Boundaries
- Permissions and Safety
- Data and State Contract
- Verification Contract
- Output Contract
- Stop Conditions
- Done Criteria
- Forbidden Assumptions

Agent PRD can be `execution_ready` only when current product and execution requirements have visible `AC`, `VER`, and traceable product context. It must cover the product problem, users or explicit unknown-user posture, goals, success measures, scope, use cases, functional requirements, non-functional guardrails, acceptance, release/roadmap, risks, assumptions, dependencies, traceability, input, execution, verification, output, stop, and done criteria. Blocking gates must pass, and unresolved decisions must be either non-blocking or deferred.

The Agent PRD must be content-dense, not only structurally complete. Required PRD and appendix sections must contain non-trivial body text, and the document must visibly cover the current-phase requirement, acceptance, verification, input, execution, output, stop, and done refs from the contract. A heading-only PRD or a document that merely lists refs is not execution-ready.

## HLD

Stage 3 writes `high-level-design.json`, `high-level-design.md`, and `hld-semantic-review.json`. The JSON file is the structured source used by validators and downstream automation. The Markdown file is the formal HLD document that a human or implementation agent reads. The semantic review file is the independent quality gate that rejects wrong-meaning or weak HLDs. A JSON-only HLD is not a complete Stage 3 deliverable.

`high-level-design.json` must include:

- `design_status=ready`
- `source_artifacts.agent_prd_ref=agent-prd.md`
- non-empty `contract_refs`
- `architecture_summary`
- `component_boundaries`
- `data_and_state_design`
- `integration_points`
- `verification_strategy`
- `risk_controls`
- `control_flow_design`
- `data_flow_design`
- `data_objects`
- `interface_contracts`
- `state_model`
- `technical_decisions`
- `implementation_design`
- `environment_requirements`
- `real_acceptance_plan`
- `design_gate_report`

The HLD is not allowed to introduce product facts. It is a design view over the approved Human PRD, execution-ready Agent PRD, requirement table, and canonical contract refs.

Ready HLD must be implementation-ready. `control_flow_design` must describe ordered triggers, components, inputs, outputs, interactions, branches, and failure behavior. `data_flow_design` must describe sources, transformations, targets, and persistence or retention when relevant. `data_objects` must describe fields and lifecycle; each field must be an object with `name`, boolean `required`, and `meaning`. `interface_contracts` must describe provider, consumer, exact invocation, inputs, outputs, error semantics, and `SRC-*` source evidence. Loose interface wording such as "or equivalent", "documented methods or", "when needed", or "as needed" is forbidden in ready HLD. `technical_decisions` must describe decision, rationale, and implementation notes.

`high-level-design.md` must render the same design as a concise formal HLD document. A ready Markdown HLD must include these sections: `Revision History`, `Scope And Goals`, `Architecture Overview`, `Control Flow`, `Data Flow`, `Data Objects`, `Interface Contracts`, `State Model`, `Technical Decisions`, `Implementation Design`, `Real Acceptance Plan`, `Risks And Guardrails`, and `References`. It must include at least one Mermaid diagram, structured tables for design details, current design refs, source links to `contract-envelope.json` or `high-level-design.json`, source-backed interface precision, exact invocation boundaries, executable acceptance command, preconditions, expected artifact paths, mechanical checks, and failure criteria. Heading-only, citation-only, or JSON-summary prose is not sufficient.

`real_acceptance_plan` must use a concrete confirmed real environment and concrete confirmed real data, list acceptance command, preconditions, execution steps, expected results, expected artifact paths, mechanical checks, failure criteria, evidence to capture, acceptance owner, and `mock_policy=forbidden`. It must include `environment_source_refs`, `real_data_source_refs`, and `acceptance_owner_source_refs` pointing to `SRC-*` evidence. Mock, stub, fake, simulated, synthetic, deferred, placeholder, `TBD`, or "to be provided later" acceptance inputs are forbidden in ready HLD. If real environment, real data, executable command, expected artifact paths, or failure criteria are unknown, Stage 3 must ask the user or produce a blocked HLD.

Ready HLD `design_gate_report` is the HLD's internal readiness gate packet. It must not replace the independent semantic review. It must contain pass gates with these `gate_key` values: `source_readiness`, `control_flow_readiness`, `data_flow_and_object_readiness`, `interface_state_readiness`, `technical_implementation_readiness`, `real_acceptance_readiness`, `hld_document_readiness`, and `task_boundary_readiness`. Each gate must include `check_id`, `name`, `gate_key`, `status=pass`, non-empty `evidence_refs`, non-empty `evidence_summary`, and empty `required_fix`.

`hld-semantic-review.json` must independently review the HLD with fixed dimensions: `source_traceability`, `control_flow_completeness`, `data_flow_and_objects`, `interface_precision`, `technical_implementation`, `executable_acceptance`, `markdown_parity`, `no_untraced_invention`, and `task_boundary`. A ready HLD requires `review_status=pass`, every dimension `status=pass`, non-empty findings, contract refs, required `SRC-*` source refs for source/interface/acceptance/Markdown parity dimensions, and empty required fixes.

`execution-task-plan.json`, task graphs, task aliases, dependency edges, parallel groups, and implementation task cards are forbidden outputs for this workflow.

## Render Block Rule

Every meaningful PRD section must be backed by `RB-*` with:

- target: `human_prd` or `agent_prd`
- section
- content type
- `contract_refs`
- `source_refs`
- allowed inference
- unsupported claims
- status

Unsupported claims must be empty for ready outputs.

Requested PRDs must have at least one `RB-*` for their target. Ready PRDs require every target `RB-*` to be `ready`, with non-empty `contract_refs` and `source_refs`.

## Traceability Summary

`traceability_summary.render_traceability` must match `render_blocks`.

`traceability_summary.requirement_traceability` must match `traceability`.

`decision_traceability` is typed:

- `decision_type=open_question`: `decision_ref` must be `Q-*`; status is `open`, `resolved`, `deferred`, or `superseded`.
- `decision_type=assumption`: `decision_ref` must be `ASM-*`; status is `open`, `resolved`, `deferred`, or `superseded`.
- `decision_type=user_confirmation`: `decision_ref` must be `SRC-*` with `source_type=user_confirmation`; status must be `confirmed`.

Every decision trace must include non-empty `affected_refs`.

Resolved `Q-*` and `ASM-*` objects require non-empty `resolution_refs`. `TRACE.relation` must be one of `stated_by`, `confirmed_by`, `inferred_from`, `assumes`, `resolves`, `blocks`, or `renders`.
