# PRD Rendering

Use this reference in Stage 2 after Stage 1 has produced a validator-clean `contract-envelope.json`.

Stage 2 creates two sibling renders from the same requirement table and canonical objects:

- `agent-prd.md`: complete English execution-ready PRD for downstream agents.
- `human-prd.md`: concise, formal Simplified Chinese review brief for human approval.

Neither PRD is a new source of product truth. If a PRD needs a fact that is missing from `contract-envelope.json`, return to Stage 1 and update the requirement table first.

Use `prd-quality-reference.md` as a quality bar for depth, traceability, and review usefulness. It is a reference package, not a current-product source. Do not copy its domain facts, component names, interface details, acceptance rules, or roadmap items into the current PRDs unless those facts also exist in the current `contract-envelope.json`.

## Best-Practice Basis

The rendering rules combine common PRD guidance and agent-instruction guidance:

- PRDs align teams around what is being built, who it benefits, objectives, assumptions, scope, dependencies, and release requirements.
- Strong product goals are measurable and tied to roadmap decisions.
- Human review briefs need clear purpose, scope, approach, acceptance, roadmap, risks, and source evidence.
- Agent-facing instructions need clear audience, context, workflow position, desired output, sequential steps, success criteria, tool boundaries, and evals.
- Agent systems need explicit permissions, safety boundaries, and evaluation criteria.

## Agent PRD

Audience: another agent that must consume a real PRD without guessing.

Language: English.

Purpose: define the product decision and execution-ready delivery contract. The Agent PRD is not merely an agent instruction sheet. It must first be a complete product requirements document, then include an agent-facing execution appendix.

An execution-ready Agent PRD has two required layers:

1. Product PRD body: the complete product requirements document.
2. Agent Execution Appendix: traceable agent instructions and runtime boundaries.

The Product PRD body must include these sections:

- `Document Metadata`
- `Executive Summary`
- `Problem and Background`
- `Target Users and Personas`
- `Goals and Outcomes`
- `Success Metrics`
- `Scope and Non-Goals`
- `User Stories and Use Cases`
- `Functional Requirements`
- `Non-Functional Requirements and Guardrails`
- `User Flow or UX Notes`
- `Acceptance Criteria`
- `Release Plan and Roadmap`
- `Risks, Assumptions, and Dependencies`
- `Open Questions`
- `Traceability`

The Agent Execution Appendix must include these sections:

- `Source of Truth`
- `Reader and Mission`
- `Requirement Trace`
- `Input Contract`
- `Execution Contract`
- `Tool and Integration Boundaries`
- `Permissions and Safety`
- `Data and State Contract`
- `Verification Contract`
- `Output Contract`
- `Stop Conditions`
- `Done Criteria`
- `Forbidden Assumptions`

Execution-ready means both layers are present and consistent. A document that only contains the appendix or only restates contract refs is not an execution-ready PRD.

Each section must cite canonical IDs from the contract where relevant. The Agent PRD must not introduce implementation details, technologies, tools, permissions, data fields, tests, or acceptance rules that are absent from the requirement table or canonical objects. If a useful PRD fact is missing from the contract, either derive it from an explicit requirement-table row or mark it as an open question/assumption and downgrade readiness if it blocks product clarity, verification, output, safety, or execution.

If required `IN`, `EXE`, `VER`, `OUT`, `STOP`, or `DONE` refs are absent or blocked, or if the PRD body cannot describe users, problem, goals, scope, requirements, acceptance, success measures, or risks from traceable contract facts, the Agent PRD must be `draft` or `blocked`, state the missing contract refs, and avoid execution-ready language.

When the contract contains implementation-model refs, the Agent PRD must make them visible and useful, not merely cite them. Cover non-empty `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, and `DCT` refs in the product body or execution appendix. For execution-like products, the implementation approach must identify the major loop, external components, public interface or method boundary, runtime states, evidence outputs, subjective judgment boundary, verification strategy, and mechanical delivery checks when those facts exist in the contract.

## Human PRD

Audience: human reviewer.

Language: professional, formal Simplified Chinese.

Purpose: brief the human on the product decision, not teach an agent how to execute. It must be concise, readable, and information-dense enough for a reviewer to decide whether the product direction is acceptable.

A review-ready Human PRD must include:

- `修订记录`
- `产品目标`
- `建设范围`
- `实现方案`
- `验收标准与方法`
- `路线图`
- `风险与待确认`
- `参考文献`

The Human PRD must answer these review questions with concrete information:

- 产品目标：为什么做、给谁用、解决什么问题。
- 建设范围：MVP 做什么、不做什么。
- 实现方案：关键组件、关键流程、关键约束如何组合成可交付产品。
- 验收标准与方法：验收标准是什么，用什么方法证明通过。
- 路线图：当前阶段交付什么，后续内容如何处理。
- 风险与待确认：哪些风险、假设、开放问题会影响审批或后续设计。

For execution-like products, Human PRD implementation approach should include enough detail for a human reviewer to understand the execution loop and boundaries without reading the Agent PRD: external components, public interfaces or methods, monitoring or orchestration loop, subjective judgment owner, mechanical checks, evidence outputs, and final acceptance owner. Keep it concise and use tables or Mermaid diagrams when they improve readability.

Hard writing requirements:

- Use professional, formal Simplified Chinese.
- Write for human reviewers, not for runtime agents.
- Use concise prose plus structured forms such as Markdown tables and Mermaid diagrams when they improve readability.
- Do not include process markers such as `Source contract:`, `Render status:`, or `render_status`.
- State only final conclusions and review-relevant facts; do not narrate how the workflow produced the document.
- Every substantive section must cite canonical refs such as `REQ-*`, `AC-*`, `SRC-*`, or related contract IDs.
- Put the revision table first. It must include version, date, revision summary, and reviser.
- Put references last. The reference section must include `contract-envelope.json` and the canonical IDs used by the brief.

The Human PRD must not repeat the full Agent PRD. Avoid agent-only sections such as `Source of Truth`, `Execution Contract`, `Tool and Integration Boundaries`, `Permissions and Safety`, `Stop Conditions`, and `Done Criteria`. Mention those concepts only as brief human-readable summaries when they affect approval.

## Sibling Consistency

- Both PRDs must cite the source contract without adding untraced facts.
- Both PRDs must cite canonical refs for important claims.
- Shared facts must match.
- Human PRD may summarize or omit Agent PRD execution detail, but it may not contradict or invent it.
- Agent PRD may be more detailed, but every meaningful detail must trace back to the Stage 1 requirement table and canonical objects.

## Review Loop

Give `human-prd.md` to the user for approval.

- If approved, record a `SRC.source_type=user_confirmation` and proceed toward Stage 3.
- If revision is requested, update `contract-envelope.json.requirement_table` first, rerender both PRDs, and repeat Stage 2.
- If rejected or insufficient, set the relevant gate to `revise` or `failed` and keep Stage 3 blocked.
