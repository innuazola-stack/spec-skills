---
name: spec-intake
description: Run a harness-first PRD intake workflow that turns a raw idea into a structured requirement table, review-gated Human/Agent PRDs, and contract-backed HLD.
---

# Spec Intake

Use this skill as the Codex adapter for the `spec-intake` harness workflow. The harness turns a raw product idea into a package that a human reviewer and downstream design consumer can inspect without guessing.

The workflow is a review-gated, self-improving generation harness. Do not treat it as a prompt-only PRD writer. Every downstream artifact must be derived from the Stage 1 structured requirement table inside `contract-envelope.json`.

## Required References

Load only what the current request needs:

- `references/intake-method.md`: use for Stage 1 requirement-table intake and clarification.
- `references/prd-rendering.md`: use for Stage 2 Human/Agent PRD rendering and review.
- `references/prd-quality-reference.md`: use in Stage 2 as a quality bar for PRD depth, traceability, and human review value; never use it as current-product evidence.
- `references/output-artifacts.md`: use before writing or reviewing `contract-envelope.json`, `human-prd.md`, `agent-prd.md`, or HLD.
- `references/hld-design.md`: use only after Human PRD approval and execution-ready Agent PRD.
- `references/quality-gates.md`: use before claiming any package is ready.

## Harness Stages

1. Stage 1: requirement table intake.
   - Register the user's idea and supplied notes as source facts.
   - Separate explicit facts, confirmed facts, bounded inferences, assumptions, and open questions.
   - Ask clarification only as boolean, single-choice, or multi-choice questions.
   - Record `contract-envelope.json.interaction_decision` before ending Stage 1.
   - Collect or block on the PRD-ready support Stage 2 needs: product context, target-user posture, MVP boundary, acceptance and verification method, implementation approach, roadmap, risks/open decisions, sources, and agent execution refs.
   - For executor, agent, adapter, CLI, automation, scheduler, or tool-orchestration ideas, also collect execution topology: external components, authoritative component sources, public interface boundary, execution loop, state handling, subjective judgment boundary, evidence chain, and mechanical delivery checks.
   - Produce or update `contract-envelope.json.requirement_table`.
   - End Stage 1 only after a real Stage 1 package exists and `validate_spec_intake_package.py <output-dir> --stage stage1` passes.
   - If blocking information is missing, keep affected targets draft or blocked.
2. Stage 2: PRD rendering and Human PRD review.
   - Render Agent PRD in English as an execution-ready PRD: a complete product requirements document plus a traceable agent execution appendix.
   - Render Human PRD in professional Simplified Chinese as a concise, information-dense human review brief with revision record, product goal, construction scope, implementation approach, acceptance criteria and methods, roadmap, risks/open decisions, and references.
   - Use `references/prd-quality-reference.md` to calibrate specificity, structure, and review usefulness; do not copy its domain facts or treat it as evidence for the current product.
   - Keep both PRDs as sibling outputs from the requirement table and canonical objects.
   - Validate the PRD-only package with `validate_spec_intake_package.py <output-dir> --stage stage2`; Stage 2 must not include HLD or task-plan artifacts.
   - Give `human-prd.md` to the user for approval.
   - If the user requests revision, update the requirement table first, then rerender both PRDs.
   - Do not enter Stage 3 until `harness_workflow.approval_gates.human_prd_review.status=approved` with a `SRC.source_type=user_confirmation` ref.
3. Stage 3: HLD.
   - Use only an approved Human PRD, execution-ready Agent PRD, and canonical requirement table.
   - Produce `high-level-design.json` as a structured implementation design with architecture summary, component boundaries, control flow, data flow, data objects, interface contracts, state model, technical decisions, implementation design, environment requirements, real acceptance plan, risk controls, and design gates.
   - Produce `high-level-design.md` as the formal HLD document with revision history, scope/goals, architecture overview, control flow, data flow, data objects, interface contracts, state model, technical decisions, implementation design, real acceptance plan, risks/guardrails, references, diagrams, tables, and canonical refs.
   - Produce `hld-semantic-review.json` as an independent semantic review artifact covering source traceability, control flow, data/data objects, interface precision, technical implementation, executable acceptance, Markdown parity, untraced invention, and task boundary.
   - Ask the user for missing Stage 3 information when real environment, real data, interface documentation, permissions, deployment constraints, acceptance owner, or other HLD-critical facts are unclear.
   - Do not produce task plans, task graphs, dependency edges, or implementation task cards.

## Output Package

When creating a final package, write this shape unless the user names another destination:

```text
<output-dir>/
  contract-envelope.json
  human-prd.md
  agent-prd.md
  high-level-design.json
  high-level-design.md
  hld-semantic-review.json
  intake-notes.md
```

`contract-envelope.json` is the source of truth. It must include `harness_workflow`, `interaction_decision`, and `requirement_table`. `human-prd.md`, `agent-prd.md`, and HLD are renders or design views from that contract, never independent sources. `high-level-design.json` is the structured HLD source; `high-level-design.md` is the readable HLD deliverable. A JSON-only HLD is incomplete.

A Stage 1-only package contains `contract-envelope.json` only. Do not include Human PRD, Agent PRD, HLD, or legacy task-plan files before Stage 2 or Stage 3 runs.

## Hard Rules

- Requirement table first: no Human PRD, Agent PRD, or HLD fact may exist only in prose.
- Interaction decision first: Stage 1 must explicitly record whether it is asking the user, proceeding without questions, or producing a blocked draft.
- Closed questions only: clarification questions must be `boolean`, `single_choice`, or `multi_choice` with explicit options.
- PRD-ready means real support: `proceed_without_questions` is allowed only when Stage 1 can support both PRDs with source-backed product context, user posture, scope, acceptance/verification, implementation approach, roadmap, risks/open decisions, and `IN`/`EXE`/`VER`/`OUT`/`STOP`/`DONE` refs.
- Execution topology required: for executor, agent, adapter, CLI, automation, scheduler, or tool-orchestration ideas, Stage 1 must capture source-backed control flow, modules, technical decisions, state handling, evidence outputs, judgment boundaries, and delivery checks, or record blocked questions/assumptions.
- Target the real blocker: for executor, agent, adapter, CLI, or automation ideas, first-round questions must cover input contract, external component boundary, source availability, completion/output contract, judgment boundary, and delivery-check boundary before secondary details.
- Honest unknowns: unknown facts become `Q`, `ASM`, `STOP`, or blocked gates.
- No hallucinated completion: bounded inferences must cite source refs, include `TRACE.relation=inferred_from`, and material assumptions must block readiness.
- Human review gate: Stage 3 is forbidden until Human PRD approval is recorded as a user-confirmation source.
- No silent execution readiness: Agent PRD can be `execution_ready` only when it is a complete PRD with traceable product context, success measures, requirements, acceptance, risks, and agent execution objects, verification, stop conditions, and done criteria.
- No thin PRDs: Agent PRD required sections must contain meaningful body text and cover current-phase requirement, acceptance, verification, input, execution, output, stop, and done refs.
- No missing topology: Agent PRD must also cover non-empty implementation-model refs such as `FLOW`, `DATA`, `MOD`, `TECH`, `STATE`, and `DCT`; otherwise an execution-ready PRD can omit the implementation approach needed by downstream design.
- No thin Human PRD: Human PRD core sections must contain concrete reviewable content plus canonical refs, not only headings or citations.
- Quality reference is not evidence: the real Stage 2 reference package may calibrate PRD quality, but it must not contribute current-product facts, requirements, methods, components, acceptance criteria, or roadmap items.
- Stage state must agree: Stage 2 summaries must show Stage 1 and Stage 2 ready, Stage 3 not ready, and pending Human PRD review must keep Stage 3 blocked.
- HLD must be implementation-ready design: ready HLD requires structured control flow, data flow, data objects, interface contracts, state model, technical decisions, implementation design, environment requirements, and real acceptance plan with contract refs.
- HLD document required: ready Stage 3 must include `high-level-design.md` with required HLD sections, diagrams, tables, current design refs, source artifact references, source-backed interface precision, exact invocation boundaries, executable acceptance command, preconditions, expected artifact paths, mechanical checks, and failure criteria; a JSON-only or thin HLD cannot pass.
- Independent semantic review required: ready Stage 3 must include `hld-semantic-review.json` with all required semantic dimensions passing. The HLD cannot rely only on its own design gates.
- Source-backed interfaces: ready HLD interface contracts must cite `SRC-*` evidence, use exact invocation boundaries, and avoid loose fallback wording such as "or equivalent", "when needed", or "as needed".
- Executable acceptance design: ready HLD real acceptance must include acceptance command, preconditions, expected artifact paths, mechanical checks, and failure criteria in addition to real environment, real data, expected results, evidence capture, and acceptance owner.
- Real acceptance only: ready HLD must define concrete confirmed real environment, concrete confirmed real data, execution steps, expected results, evidence capture, acceptance owner, `SRC-*` evidence refs for environment/data/owner, and `mock_policy=forbidden`; mock, stub, fake, simulated, synthetic, deferred, placeholder, `TBD`, and "to be provided later" acceptance inputs are forbidden.
- Fixed HLD design gates: ready HLD must include separate passing `gate_key` values for source readiness, control flow, data/data objects, interface/state, technical implementation, real acceptance, HLD document readiness, and task boundary; a generic single pass gate is forbidden.
- No task output: task plans, task graphs, dependency edges, parallel groups, implementation task cards, and task decomposition are outside this workflow.
- Preserve sibling consistency: Human PRD and Agent PRD are sibling renders from the requirement table and contract, not sources for each other.
- Agent PRD complete, Human PRD brief: Agent PRD is the full execution-ready PRD for another agent; Human PRD gives a concise, formal, evidence-backed human approval brief.

## Completion Check

Before claiming Stage 1 completion, verify:

- `contract-envelope.json` parses and contains `harness_workflow`, `interaction_decision`, `requirement_table`, canonical objects, derived views, and gate report.
- `proceed_without_questions` is backed by PRD-ready Stage 1 support; otherwise `ask_user` or `blocked_draft` is recorded.
- all unresolved clarification questions are boolean or choice questions with options.
- `python skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage1` passes.
- no `human-prd.md`, `agent-prd.md`, `high-level-design.json`, `high-level-design.md`, or `execution-task-plan.json` exists in the Stage 1 package.

Before finalizing the full workflow, verify:

- `contract-envelope.json` parses and contains `harness_workflow`, `interaction_decision`, `requirement_table`, canonical objects, derived views, and gate report.
- all unresolved clarification questions are boolean or choice questions with options.
- Human PRD and Agent PRD state their source contract and do not add untraced facts.
- Stage 2 PRD package passes `python skill/scripts/validate_spec_intake_package.py <output-dir> --stage stage2` before Human PRD approval is treated as reviewable.
- Stage 2 contract summary matches the review-gated stage state.
- Stage 3 ready HLD has approved Human PRD evidence and contract-backed design refs.
- Stage 3 ready HLD has structured implementation design, a formal `high-level-design.md`, an independent passing `hld-semantic-review.json`, covers current requirement/execution/implementation refs, and contains a no-mock real acceptance plan.
- no `execution-task-plan.json` or task decomposition artifact is present.
- validation output is reported honestly, including any skipped checks.
